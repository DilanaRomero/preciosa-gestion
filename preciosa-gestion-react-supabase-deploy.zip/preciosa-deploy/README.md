# Preciosa Gestión

Sistema web para administrar el negocio de joyas: inventario, productos combinados, clientes TikTok, ventas en lives, pagos, entregas y horas de trabajadores.

## Stack
- React + Vite
- Supabase (PostgreSQL + Auth + RLS)
- Vercel para hosting

## Base de datos
1. Ejecutar `supabase/schema.sql` completo.
2. Después ejecutar `supabase/migration_v2.sql`.

## Desarrollo local
Crear `.env.local` a partir de `.env.example` con las variables de Supabase y ejecutar:

`npm install`

`npm run dev`

## Producción
Ver `DEPLOY_VERCEL.md`.

No se incluyen claves privadas o secretos en el repositorio.
