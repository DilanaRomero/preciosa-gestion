import { useEffect, useMemo, useState } from 'react'
import { supabase } from './lib/supabase'

const menu = [
  ['dashboard', 'Resumen', '◉'],
  ['inventory', 'Inventario', '◇'],
  ['customers', 'Clientes', '◌'],
  ['live', 'Live', '●'],
  ['payments', 'Pagos', '$'],
  ['shipments', 'Entregas', '↗'],
  ['workers', 'Trabajadores', '◫'],
]

const money = (n = 0) => `Bs ${Number(n).toFixed(2)}`

function App() {
  const [session, setSession] = useState(null)
  const [view, setView] = useState('dashboard')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => setSession(next))
    return () => sub.subscription.unsubscribe()
  }, [])

  if (loading) return <div className="splash"><div className="logo-mark">P</div><p>Cargando Preciosa Gestión…</p></div>
  if (!session) return <Login />

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo-mark">P</div>
          <div><strong>Preciosa</strong><span>Gestión</span></div>
        </div>
        <div className="live-badge"><span className="dot" /> Sistema conectado</div>
        <nav>
          {menu.map(([id, label, icon]) => (
            <button key={id} className={view === id ? 'nav-item active' : 'nav-item'} onClick={() => setView(id)}>
              <span className="nav-icon">{icon}</span>{label}
            </button>
          ))}
        </nav>
        <button className="user-mini" onClick={() => supabase.auth.signOut()}>
          <div className="avatar">{(session.user.email?.[0] || 'U').toUpperCase()}</div>
          <div><b>{session.user.email?.split('@')[0]}</b><span>Cerrar sesión</span></div>
        </button>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <div className="eyebrow">PRECIOSA GESTIÓN</div>
            <h1>{menu.find(x => x[0] === view)?.[1] || 'Resumen'}</h1>
          </div>
          <div className="top-actions"><span className="today">Hoy · {new Date().toLocaleDateString('es-BO')}</span></div>
        </header>
        <section className="page-wrap">
          {view === 'dashboard' && <Dashboard />}
          {view === 'inventory' && <Inventory />}
          {view === 'customers' && <Customers />}
          {view === 'live' && <Live />}
          {view === 'payments' && <Payments />}
          {view === 'shipments' && <Shipments />}
          {view === 'workers' && <Workers />}
        </section>
      </main>
    </div>
  )
}

function Login() {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMessage('')
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin } })
    setBusy(false)
    setMessage(error ? error.message : 'Revisa tu correo: te enviamos el enlace de acceso.')
  }
  return <div className="login-page"><div className="login-card">
    <div className="logo-mark big">P</div><div className="eyebrow">PRECIOSA GESTIÓN</div><h1>Controla tu negocio desde un solo lugar.</h1><p className="muted">Inventario, ventas de TikTok, clientes, pagos, entregas y horas de trabajo.</p>
    <form onSubmit={submit}><label>Correo de acceso<input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="tu@correo.com" /></label><button className="primary wide" disabled={busy}>{busy ? 'Enviando…' : 'Entrar con enlace seguro'}</button></form>
    {message && <div className="notice">{message}</div>}
  </div></div>
}

function Stat({label, value, caption}) { return <div className="stat-card"><span>{label}</span><strong>{value}</strong><small>{caption}</small></div> }

function Dashboard() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => { (async () => {
    const [{ count: customers }, { count: units }, { count: reserved }, { data: balances }] = await Promise.all([
      supabase.from('customers').select('*', { count: 'exact', head: true }),
      supabase.from('product_units').select('*', { count: 'exact', head: true }),
      supabase.from('product_units').select('*', { count: 'exact', head: true }).eq('status', 'reserved'),
      supabase.from('order_balances').select('paid_amount')
    ])
    const revenue = (balances || []).reduce((a, o) => a + Number(o.paid_amount || 0), 0)
    setStats({ customers: customers || 0, units: units || 0, reserved: reserved || 0, revenue }); setLoading(false)
  })() }, [])
  if (loading) return <div className="empty">Cargando resumen…</div>
  return <>
    <div className="hero"><div><span className="eyebrow">CONTROL CENTRAL</span><h2>Tu negocio, claro y ordenado.</h2><p>El inventario baja físicamente cuando se entrega; las reservas quedan visibles mientras esperan.</p></div><div className="hero-orb">✦</div></div>
    <div className="stats-grid"><Stat label="Clientes" value={stats.customers} caption="perfiles registrados"/><Stat label="Unidades" value={stats.units} caption="productos terminados"/><Stat label="Reservadas" value={stats.reserved} caption="pendientes de entrega"/><Stat label="Ventas con pago" value={money(stats.revenue)} caption="según pedidos registrados"/></div>
    <div className="dashboard-grid"><div className="panel"><div className="panel-title"><div><b>Flujo recomendado</b><span>Así funciona el negocio dentro del sistema</span></div></div><div className="steps">{[['01','Armar','Joya + empaque → costo y precio'],['02','Live','“mío” → reserva individual'],['03','Cobrar','Abonos parciales → deuda real'],['04','Entregar','Agrupa compras → salida física']].map(([n,t,s])=><div className="step" key={n}><span>{n}</span><div><b>{t}</b><small>{s}</small></div></div>)}</div></div><div className="panel accent"><b>Regla clave</b><p>Una reserva no elimina la pieza del inventario físico. La salida ocurre al marcarla como enviada o entregada.</p></div></div>
  </>
}

function Inventory() {
  const [units, setUnits] = useState([]); const [ingredients, setIngredients] = useState([]); const [products, setProducts] = useState([]); const [tab, setTab] = useState('units'); const [form, setForm] = useState({ name: '', cost: '', multiplier: '1.5' }); const [unitForm, setUnitForm] = useState({ product_id: '', code: '' }); const [message, setMessage] = useState('')
  const load = async () => { const [a,b,c] = await Promise.all([supabase.from('product_units').select('id,code,status,product:products(name,sale_price,cost)').order('created_at',{ascending:false}), supabase.from('ingredients').select('*').order('name'), supabase.from('products').select('*').order('name')]); setUnits(a.data||[]); setIngredients(b.data||[]); setProducts(c.data||[]) }
  useEffect(()=>{load()},[])
  const createProduct = async (e)=>{e.preventDefault(); const cost=Number(form.cost||0); const mult=Number(form.multiplier||1.5); const {error}=await supabase.from('products').insert({name:form.name,cost,multiplier:mult,sale_price:Number((cost*mult).toFixed(2))}); setMessage(error?error.message:'Producto creado'); setForm({name:'',cost:'',multiplier:'1.5'}); if(!error) load()}
  const createUnit = async (e)=>{e.preventDefault(); const {data,error}=await supabase.rpc('assemble_product_unit',{p_product_id:unitForm.product_id,p_unit_code:unitForm.code}); setMessage(error?error.message:`Unidad armada: ${data}`); setUnitForm({product_id:'',code:''}); if(!error) load()}
  return <>
    <div className="toolbar"><div><p className="muted">Controla componentes, productos combinados y unidades con código único.</p></div><div className="tabs"><button className={tab==='units'?'tab active':'tab'} onClick={()=>setTab('units')}>Unidades</button><button className={tab==='products'?'tab active':'tab'} onClick={()=>setTab('products')}>Productos</button><button className={tab==='ingredients'?'tab active':'tab'} onClick={()=>setTab('ingredients')}>Insumos</button></div></div>
    {message && <div className="notice">{message}</div>}
    {tab==='units' && <div className="two-col"><div className="panel"><div className="panel-title"><div><b>Unidades terminadas</b><span>Cada pieza física tiene su código</span></div></div><div className="table-wrap"><table><thead><tr><th>Código</th><th>Producto</th><th>Costo</th><th>Venta</th><th>Estado</th></tr></thead><tbody>{units.map(u=><tr key={u.id}><td><b>{u.code}</b></td><td>{u.product?.name}</td><td>{money(u.product?.cost)}</td><td>{money(u.product?.sale_price)}</td><td><span className={`pill ${u.status}`}>{u.status}</span></td></tr>)}{!units.length&&<tr><td colSpan="5" className="empty">Aún no hay unidades.</td></tr>}</tbody></table></div></div><div className="panel"><div className="panel-title"><div><b>Armar unidad</b><span>Consume automáticamente los componentes de la receta</span></div></div><form className="stack-form" onSubmit={createUnit}><label>Producto<select required value={unitForm.product_id} onChange={e=>setUnitForm({...unitForm,product_id:e.target.value})}><option value="">Selecciona…</option>{products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label><label>Código único<input required value={unitForm.code} onChange={e=>setUnitForm({...unitForm,code:e.target.value.toUpperCase()})} placeholder="JOY-0001"/></label><button className="primary">Armar unidad</button></form></div></div>}
    {tab==='products' && <div className="two-col"><div className="panel"><div className="panel-title"><div><b>Productos combinados</b><span>El costo se calcula desde sus componentes</span></div></div><div className="cards-list">{products.map(p=><div className="list-card" key={p.id}><div><b>{p.name}</b><small>Costo {money(p.cost)} · x{p.multiplier}</small></div><strong>{money(p.sale_price)}</strong></div>)}{!products.length&&<div className="empty">Aún no hay productos.</div>}</div></div><div className="panel"><div className="panel-title"><div><b>Crear producto</b><span>Luego podremos definir su composición</span></div></div><form className="stack-form" onSubmit={createProduct}><label>Nombre<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Collar corazón + caja rosada" /></label><div className="inline-fields"><label>Costo base<input type="number" min="0" step="0.01" required value={form.cost} onChange={e=>setForm({...form,cost:e.target.value})}/></label><label>Multiplicador<input type="number" min="0.01" step="0.01" required value={form.multiplier} onChange={e=>setForm({...form,multiplier:e.target.value})}/></label></div><button className="primary">Crear producto base</button></form></div></div>}
    {tab==='ingredients' && <div className="panel"><div className="panel-title"><div><b>Insumos</b><span>Collares, cajas, empaques y otros componentes</span></div></div><div className="table-wrap"><table><thead><tr><th>Código</th><th>Insumo</th><th>Costo unitario</th><th>Existencia</th></tr></thead><tbody>{ingredients.map(i=><tr key={i.id}><td>{i.code}</td><td>{i.name}</td><td>{money(i.unit_cost)}</td><td>{i.stock_qty}</td></tr>)}{!ingredients.length&&<tr><td colSpan="4" className="empty">Aún no hay insumos. Los cargaremos desde el módulo de compras.</td></tr>}</tbody></table></div></div>}
  </>
}

function Customers(){ const [rows,setRows]=useState([]); const [form,setForm]=useState({tiktok_username:'',full_name:'',phone:'',city:''}); const [msg,setMsg]=useState(''); const load=async()=>{const {data}=await supabase.from('customer_balances').select('*').order('created_at',{ascending:false});setRows(data||[])}; useEffect(()=>{load()},[]); const add=async e=>{e.preventDefault();const {error}=await supabase.from('customers').insert({...form,tiktok_username:form.tiktok_username.replace(/^@/, '')});setMsg(error?error.message:'Cliente guardado');setForm({tiktok_username:'',full_name:'',phone:'',city:''});if(!error)load()}; return <div className="two-col"><div className="panel"><div className="panel-title"><div><b>Clientes</b><span>Un perfil por usuario de TikTok</span></div></div><div className="table-wrap"><table><thead><tr><th>TikTok</th><th>Nombre</th><th>WhatsApp</th><th>Deuda</th></tr></thead><tbody>{rows.map(r=><tr key={r.customer_id}><td>@{r.tiktok_username}</td><td>{r.full_name||'—'}</td><td>{r.phone||'—'}</td><td><b className={Number(r.balance)>0?'debt':''}>{money(r.balance)}</b></td></tr>)}{!rows.length&&<tr><td colSpan="4" className="empty">Aún no hay clientes.</td></tr>}</tbody></table></div></div><div className="panel"><div className="panel-title"><div><b>Registrar cliente</b><span>Puedes empezar solo con TikTok</span></div></div>{msg&&<div className="notice">{msg}</div>}<form className="stack-form" onSubmit={add}><label>Usuario de TikTok<input required value={form.tiktok_username} onChange={e=>setForm({...form,tiktok_username:e.target.value})} placeholder="@juanita20"/></label><label>Nombre completo<input value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})}/></label><label>WhatsApp<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>Ciudad<input value={form.city} onChange={e=>setForm({...form,city:e.target.value})}/></label><button className="primary">Guardar cliente</button></form></div></div> }

function Live(){ const [customers,setCustomers]=useState([]); const [units,setUnits]=useState([]); const [customerId,setCustomerId]=useState(''); const [code,setCode]=useState(''); const [price,setPrice]=useState(''); const [orders,setOrders]=useState([]); const [msg,setMsg]=useState(''); const load=async()=>{const [c,u,o]=await Promise.all([supabase.from('customers').select('id,tiktok_username,full_name').order('tiktok_username'),supabase.from('product_units').select('id,code,status,product:products(name,sale_price)').eq('status','available').order('code'),supabase.from('orders').select('id,order_number,order_date,total_amount,customer:customers(tiktok_username)').order('created_at',{ascending:false}).limit(12)]);setCustomers(c.data||[]);setUnits(u.data||[]);setOrders(o.data||[])}; useEffect(()=>{load()},[]); useEffect(()=>{const match=units.find(u=>u.code===code.toUpperCase());if(match&&!price)setPrice(match.product?.sale_price||'')},[code,units,price]); const reserve=async e=>{e.preventDefault();setMsg('');const {data,error}=await supabase.rpc('reserve_product_unit',{p_unit_code:code.toUpperCase(),p_customer_id:customerId,p_price:Number(price)});setMsg(error?error.message:`Reserva registrada: ${data}`);if(!error){setCode('');setPrice('');load()}}; const selected=units.find(u=>u.code===code.toUpperCase()); return <div className="two-col live-layout"><div className="panel live-panel"><div className="live-header"><div><span className="eyebrow">REGISTRO RÁPIDO</span><h2>“MÍO” EN EL LIVE</h2></div><div className="live-circle">●</div></div><p className="muted">Selecciona cliente, escribe/escanéa el código y confirma el precio anunciado.</p>{msg&&<div className="notice">{msg}</div>}<form className="stack-form" onSubmit={reserve}><label>Cliente<select required value={customerId} onChange={e=>setCustomerId(e.target.value)}><option value="">Selecciona…</option>{customers.map(c=><option value={c.id} key={c.id}>@{c.tiktok_username}{c.full_name?` · ${c.full_name}`:''}</option>)}</select></label><label>Código de la joya<input autoFocus required value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder="JOY-0001"/></label>{selected&&<div className="selected-product"><b>{selected.product?.name}</b><span>Estado: disponible · Sugerido {money(selected.product?.sale_price)}</span></div>}<label>Precio anunciado<input type="number" min="0" step="0.01" required value={price} onChange={e=>setPrice(e.target.value)}/></label><button className="primary live-btn">REGISTRAR MÍO</button></form></div><div className="panel"><div className="panel-title"><div><b>Últimas reservas</b><span>Se ordenan por registro</span></div></div><div className="cards-list">{orders.map(o=><div className="list-card" key={o.id}><div><b>{o.order_number}</b><small>@{o.customer?.tiktok_username} · {o.order_date}</small></div><strong>{money(o.total_amount)}</strong></div>)}{!orders.length&&<div className="empty">Todavía no hay reservas.</div>}</div></div></div> }

function Payments(){
  const [customers,setCustomers]=useState([]); const [balances,setBalances]=useState([]); const [customerId,setCustomerId]=useState(''); const [amount,setAmount]=useState(''); const [method,setMethod]=useState('transfer'); const [msg,setMsg]=useState('');
  const load=async()=>{const [{data:c},{data:b}]=await Promise.all([supabase.from('customers').select('id,tiktok_username,full_name').order('tiktok_username'),supabase.from('customer_balances').select('*').gt('balance',0).order('balance',{ascending:false})]);setCustomers(c||[]);setBalances(b||[])};
  useEffect(()=>{load()},[]);
  const add=async e=>{e.preventDefault();setMsg('');const {error}=await supabase.rpc('register_customer_payment',{p_customer_id:customerId,p_amount:Number(amount),p_method:method});setMsg(error?error.message:'Pago registrado y aplicado a las deudas más antiguas.');if(!error){setAmount('');load()}};
  const selected=customers.find(c=>c.id===customerId);
  return <div className="two-col"><div className="panel"><div className="panel-title"><div><b>Cuentas por cobrar</b><span>La deuda se ve por cliente</span></div></div><div className="table-wrap"><table><thead><tr><th>Cliente</th><th>Comprado</th><th>Pagado</th><th>Deuda</th></tr></thead><tbody>{balances.map(r=><tr key={r.customer_id}><td>@{r.tiktok_username}{r.full_name?` · ${r.full_name}`:''}</td><td>{money(r.purchased_amount)}</td><td>{money(r.paid_amount)}</td><td><b className="debt">{money(r.balance)}</b></td></tr>)}{!balances.length&&<tr><td colSpan="4" className="empty">No hay deudas pendientes.</td></tr>}</tbody></table></div></div><div className="panel"><div className="panel-title"><div><b>Registrar pago</b><span>Un solo pago puede cubrir varios pedidos del cliente</span></div></div>{msg&&<div className="notice">{msg}</div>}<form className="stack-form" onSubmit={add}><label>Cliente<select required value={customerId} onChange={e=>setCustomerId(e.target.value)}><option value="">Selecciona…</option>{customers.map(c=><option value={c.id} key={c.id}>@{c.tiktok_username}{c.full_name?` · ${c.full_name}`:''}</option>)}</select></label>{selected&&<div className="selected-product"><b>Deuda actual: {money(balances.find(b=>b.customer_id===customerId)?.balance||0)}</b><span>El sistema distribuirá el pago desde el pedido más antiguo.</span></div>}<label>Monto<input type="number" min="0.01" step="0.01" required value={amount} onChange={e=>setAmount(e.target.value)}/></label><label>Método<select value={method} onChange={e=>setMethod(e.target.value)}><option value="transfer">Transferencia</option><option value="qr">QR</option><option value="cash">Efectivo</option><option value="other">Otro</option></select></label><button className="primary">Confirmar pago</button></form></div></div>
}

function Shipments(){const [rows,setRows]=useState([]);const [msg,setMsg]=useState('');const load=async()=>{const {data}=await supabase.from('order_balances').select('*').order('order_date',{ascending:false});setRows(data||[])};useEffect(()=>{load()},[]);const mark=async(id)=>{const {data,error}=await supabase.rpc('ship_order',{p_order_id:id});setMsg(error?error.message:`${data} marcado como enviado. El stock físico salió del inventario.`);if(!error)load()};return <div className="panel"><div className="panel-title"><div><b>Entregas</b><span>Al enviar, las unidades pasan de reservado a enviado</span></div></div>{msg&&<div className="notice">{msg}</div>}<div className="table-wrap"><table><thead><tr><th>Pedido</th><th>Cliente</th><th>Fecha</th><th>Saldo</th><th>Estado</th><th></th></tr></thead><tbody>{rows.map(r=><tr key={r.order_id}><td>{r.order_number}</td><td>@{r.tiktok_username}</td><td>{r.order_date}</td><td>{money(r.balance)}</td><td><span className={`pill ${r.fulfillment_status}`}>{r.fulfillment_status}</span></td><td>{r.fulfillment_status!=='shipped'&&r.fulfillment_status!=='delivered'?<button className="small-btn" onClick={()=>mark(r.order_id)}>Marcar enviado</button>:''}</td></tr>)}{!rows.length&&<tr><td colSpan="6" className="empty">No hay pedidos todavía.</td></tr>}</tbody></table></div></div>}

function Workers(){const [rows,setRows]=useState([]);const [open,setOpen]=useState(null);const [msg,setMsg]=useState('');const load=async()=>{const [{data},{data:userData}]=await Promise.all([supabase.from('attendance').select('*, worker:profiles(full_name,email)').order('clock_in',{ascending:false}).limit(50),supabase.auth.getUser()]);const mine=(data||[]).find(r=>r.worker_id===userData?.user?.id&&!r.clock_out);setRows(data||[]);setOpen(mine||null)};useEffect(()=>{load()},[]);const clockIn=async()=>{const {data,error}=await supabase.rpc('clock_in');setMsg(error?error.message:'Entrada registrada.');if(!error){setOpen(data);load()}};const clockOut=async()=>{const {data,error}=await supabase.rpc('clock_out');setMsg(error?error.message:`Salida registrada. Horas de la jornada: ${Number(data).toFixed(2)}.`);if(!error){setOpen(null);load()}};return <div className="two-col"><div className="panel"><div className="panel-title"><div><b>Mi jornada</b><span>Registra entrada y salida desde tu propia cuenta</span></div></div>{msg&&<div className="notice">{msg}</div>}<div className="work-actions">{open?<><div className="selected-product"><b>Jornada abierta</b><span>Entrada registrada; cuando termines pulsa Salida.</span></div><button className="primary" onClick={clockOut}>REGISTRAR SALIDA</button></>:<button className="primary" onClick={clockIn}>REGISTRAR ENTRADA</button>}</div></div><div className="panel"><div className="panel-title"><div><b>Historial de horas</b><span>Horas trabajadas quedan registradas para la liquidación</span></div></div><div className="table-wrap"><table><thead><tr><th>Trabajador</th><th>Entrada</th><th>Salida</th><th>Horas</th><th>Estado</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.worker?.full_name||r.worker?.email||'—'}</td><td>{new Date(r.clock_in).toLocaleString('es-BO')}</td><td>{r.clock_out?new Date(r.clock_out).toLocaleString('es-BO'):'En curso'}</td><td>{r.hours_worked?Number(r.hours_worked).toFixed(2):'—'}</td><td>{r.approved?'Aprobada':'Pendiente'}</td></tr>)}{!rows.length&&<tr><td colSpan="5" className="empty">Aún no hay marcas de asistencia.</td></tr>}</tbody></table></div></div></div>}

export default App
