-- PRECIOSA GESTIÓN · Supabase/Postgres
-- Ejecutar TODO este archivo en Supabase > SQL Editor.

create extension if not exists pgcrypto;

create type public.app_role as enum ('admin','live','cashier','fulfillment','worker');
create type public.product_status as enum ('available','reserved','prepared','shipped','delivered','cancelled');
create type public.order_status as enum ('open','confirmed','cancelled');
create type public.payment_method as enum ('cash','transfer','qr','other');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role public.app_role not null default 'worker',
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  tiktok_username text not null unique,
  full_name text,
  phone text,
  city text,
  address text,
  agency text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.ingredients (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  unit_cost numeric(12,2) not null default 0,
  stock_qty integer not null default 0 check (stock_qty >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  name text not null,
  cost numeric(12,2) not null default 0,
  multiplier numeric(8,3) not null default 1.5,
  sale_price numeric(12,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.product_components (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  ingredient_id uuid not null references public.ingredients(id) on delete restrict,
  quantity numeric(12,3) not null default 1 check (quantity > 0),
  unique(product_id, ingredient_id)
);

create table if not exists public.product_units (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete restrict,
  code text not null unique,
  status public.product_status not null default 'available',
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_id uuid not null references public.customers(id) on delete restrict,
  order_date date not null default current_date,
  status public.order_status not null default 'open',
  total_amount numeric(12,2) not null default 0,
  fulfillment_status public.product_status not null default 'reserved',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_unit_id uuid not null unique references public.product_units(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  quantity integer not null default 1 check (quantity = 1),
  unit_price numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  method public.payment_method not null,
  paid_at timestamptz not null default now(),
  note text,
  created_by uuid references public.profiles(id)
);

create table if not exists public.payment_allocations (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete cascade,
  order_id uuid not null references public.orders(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  unique(payment_id, order_id)
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  shipment_number text not null unique,
  customer_id uuid not null references public.customers(id) on delete restrict,
  status text not null default 'packed' check (status in ('packed','shipped','delivered','cancelled')),
  sent_at timestamptz,
  carrier text,
  tracking text,
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.shipment_items (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  order_item_id uuid not null unique references public.order_items(id) on delete restrict
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  worker_id uuid not null references public.profiles(id) on delete cascade,
  clock_in timestamptz not null default now(),
  clock_out timestamptz,
  break_minutes integer not null default 0,
  notes text,
  approved boolean not null default false,
  approved_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.payroll_pools (
  id uuid primary key default gen_random_uuid(),
  period_start date not null,
  period_end date not null,
  pool_amount numeric(12,2) not null default 0,
  total_hours numeric(12,2) not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  unique(period_start, period_end)
);

create table if not exists public.audit_log (
  id bigint generated by default as identity primary key,
  actor_id uuid references public.profiles(id),
  entity_type text not null,
  entity_id text,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create sequence if not exists public.order_seq start 1;
create sequence if not exists public.shipment_seq start 1;

create or replace function public.make_order_number() returns text
language sql volatile as $$ select 'PED-' || lpad(nextval('public.order_seq')::text, 6, '0') $$;
create or replace function public.make_shipment_number() returns text
language sql volatile as $$ select 'ENV-' || lpad(nextval('public.shipment_seq')::text, 6, '0') $$;

create or replace function public.current_user_role() returns public.app_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.current_user_role() = 'admin', false);
$$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, role) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), 'worker') on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.reserve_product_unit(p_unit_code text, p_customer_id uuid, p_price numeric)
returns text
language plpgsql security definer set search_path = public as $$
declare
  v_unit public.product_units%rowtype;
  v_order_id uuid;
  v_order_number text;
  v_product_id uuid;
begin
  select * into v_unit from public.product_units where upper(code)=upper(p_unit_code) for update;
  if not found then raise exception 'No existe la unidad %', p_unit_code; end if;
  if v_unit.status <> 'available' then raise exception 'La unidad % ya no está disponible (estado: %)', p_unit_code, v_unit.status; end if;
  v_product_id := v_unit.product_id;
  v_order_number := public.make_order_number();
  insert into public.orders(order_number, customer_id, total_amount, fulfillment_status, created_by)
  values(v_order_number,p_customer_id,round(p_price,2),'reserved',auth.uid()) returning id into v_order_id;
  insert into public.order_items(order_id, product_unit_id, product_id, unit_price)
  values(v_order_id,v_unit.id,v_product_id,round(p_price,2));
  update public.product_units set status='reserved' where id=v_unit.id;
  return v_order_number;
end;
$$;

grant execute on function public.reserve_product_unit(text,uuid,numeric) to authenticated;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.is_admin() to authenticated;

drop view if exists public.order_balances;
create or replace view public.order_balances with (security_invoker=true) as
select o.id as order_id, o.order_number, o.order_date, o.customer_id, c.tiktok_username, c.full_name,
       o.total_amount,
       coalesce(sum(pa.amount),0) as paid_amount,
       greatest(o.total_amount - coalesce(sum(pa.amount),0),0) as balance,
       o.fulfillment_status
from public.orders o
join public.customers c on c.id=o.customer_id
left join public.payment_allocations pa on pa.order_id=o.id
group by o.id, c.id;


drop view if exists public.customer_balances;
create or replace view public.customer_balances with (security_invoker=true) as
select c.id as customer_id, c.tiktok_username, c.full_name, c.phone, c.city, c.created_at,
       coalesce(sum(o.total_amount),0) as purchased_amount,
       coalesce(sum(coalesce(pa.paid_amount,0)),0) as paid_amount,
       greatest(coalesce(sum(o.total_amount),0)-coalesce(sum(coalesce(pa.paid_amount,0)),0),0) as balance
from public.customers c
left join public.orders o on o.customer_id=c.id and o.status <> 'cancelled'
left join (select order_id,sum(amount) paid_amount from public.payment_allocations group by order_id) pa on pa.order_id=o.id
group by c.id;

-- RLS
alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.ingredients enable row level security;
alter table public.products enable row level security;
alter table public.product_components enable row level security;
alter table public.product_units enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.payment_allocations enable row level security;
alter table public.shipments enable row level security;
alter table public.shipment_items enable row level security;
alter table public.attendance enable row level security;
alter table public.payroll_pools enable row level security;
alter table public.audit_log enable row level security;

-- Para esta primera versión, cualquier usuario autenticado puede operar los módulos.
-- Los controles finos por rol se consolidarán en la siguiente iteración.

do $$ declare t text; begin
  foreach t in array array['profiles','customers','ingredients','products','product_components','product_units','orders','order_items','payments','payment_allocations','shipments','shipment_items','attendance','payroll_pools','audit_log'] loop
    execute format('drop policy if exists "auth full %s" on public.%I', t, t);
    execute format('create policy "auth full %s" on public.%I for all to authenticated using (auth.uid() is not null) with check (auth.uid() is not null)', t, t);
  end loop;
end $$;

-- Datos demo para que se pueda probar sin cargar todo a mano.
insert into public.ingredients(code,name,unit_cost,stock_qty) values
('COLL-001','Collar corazón',35,10),
('CAJA-001','Caja rosada',10,10)
on conflict (code) do nothing;

insert into public.products(code,name,cost,multiplier,sale_price) values
('JOY-BASE-001','Collar corazón + caja rosada',45,1.5,67.50)
on conflict (code) do nothing;

-- La composición queda separada para permitir futuras recetas con más piezas.
insert into public.product_components(product_id,ingredient_id,quantity)
select p.id,i.id,1 from public.products p, public.ingredients i where p.code='JOY-BASE-001' and i.code='COLL-001'
on conflict (product_id,ingredient_id) do nothing;
insert into public.product_components(product_id,ingredient_id,quantity)
select p.id,i.id,1 from public.products p, public.ingredients i where p.code='JOY-BASE-001' and i.code='CAJA-001'
on conflict (product_id,ingredient_id) do nothing;
