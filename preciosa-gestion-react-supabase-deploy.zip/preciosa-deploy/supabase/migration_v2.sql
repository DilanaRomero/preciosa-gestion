-- PRECIOSA GESTIÓN · Migración v2
-- Ejecutar DESPUÉS de schema.sql.

-- 1) Costos: arma una unidad física consumiendo los insumos de su receta.
create or replace function public.assemble_product_unit(p_product_id uuid, p_unit_code text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_product public.products%rowtype;
  v_component record;
  v_total_cost numeric(12,2) := 0;
  v_unit_id uuid;
  v_needed integer;
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  if trim(p_unit_code) = '' then raise exception 'El código de la unidad es obligatorio'; end if;

  select * into v_product from public.products where id = p_product_id for update;
  if not found then raise exception 'No existe el producto'; end if;

  for v_component in
    select pc.ingredient_id, pc.quantity, i.name, i.unit_cost, i.stock_qty
    from public.product_components pc
    join public.ingredients i on i.id = pc.ingredient_id
    where pc.product_id = p_product_id
    order by i.code
    for update of i
  loop
    if v_component.quantity <> floor(v_component.quantity) then
      raise exception 'El insumo % usa una cantidad no entera (%). La existencia se maneja por unidades.', v_component.name, v_component.quantity;
    end if;
    v_needed := v_component.quantity::integer;
    if v_component.stock_qty < v_needed then
      raise exception 'Stock insuficiente de %. Disponible: %, necesario: %', v_component.name, v_component.stock_qty, v_needed;
    end if;
    v_total_cost := v_total_cost + (v_component.unit_cost * v_component.quantity);
  end loop;

  if not exists (select 1 from public.product_components where product_id = p_product_id) then
    raise exception 'El producto no tiene componentes/receta';
  end if;

  update public.ingredients i
  set stock_qty = i.stock_qty - pc.quantity::integer
  from public.product_components pc
  where pc.product_id = p_product_id
    and i.id = pc.ingredient_id;

  update public.products
  set cost = round(v_total_cost, 2),
      sale_price = round(v_total_cost * multiplier, 2)
  where id = p_product_id;

  insert into public.product_units(product_id, code, status)
  values (p_product_id, upper(trim(p_unit_code)), 'available')
  returning id into v_unit_id;

  insert into public.audit_log(actor_id, entity_type, entity_id, action, details)
  values(auth.uid(), 'product_unit', v_unit_id::text, 'assembled', jsonb_build_object('product_id',p_product_id,'cost',round(v_total_cost,2)));

  return upper(trim(p_unit_code));
exception when unique_violation then
  raise exception 'Ya existe una unidad con el código %', upper(trim(p_unit_code));
end;
$$;

grant execute on function public.assemble_product_unit(uuid,text) to authenticated;

-- 2) Un pedido diario por cliente: varias reservas del mismo día quedan juntas.
create unique index if not exists orders_one_active_per_customer_day
on public.orders(customer_id, order_date)
where status <> 'cancelled';

create or replace function public.reserve_product_unit(p_unit_code text, p_customer_id uuid, p_price numeric)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_unit public.product_units%rowtype;
  v_order_id uuid;
  v_order_number text;
  v_price numeric(12,2) := round(p_price,2);
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  if v_price < 0 then raise exception 'El precio no puede ser negativo'; end if;

  select * into v_unit from public.product_units where upper(code)=upper(trim(p_unit_code)) for update;
  if not found then raise exception 'No existe la unidad %', p_unit_code; end if;
  if v_unit.status <> 'available' then raise exception 'La unidad % ya no está disponible (estado: %)', p_unit_code, v_unit.status; end if;

  insert into public.orders(order_number, customer_id, order_date, status, total_amount, fulfillment_status, created_by)
  values(public.make_order_number(), p_customer_id, current_date, 'open', 0, 'reserved', auth.uid())
  on conflict (customer_id, order_date) where status <> 'cancelled'
  do update set id = public.orders.id
  returning id, order_number into v_order_id, v_order_number;

  insert into public.order_items(order_id, product_unit_id, product_id, unit_price)
  values(v_order_id, v_unit.id, v_unit.product_id, v_price);

  update public.orders
  set total_amount = total_amount + v_price,
      fulfillment_status = 'reserved'
  where id = v_order_id;

  update public.product_units set status='reserved' where id=v_unit.id;
  return v_order_number;
end;
$$;

grant execute on function public.reserve_product_unit(text,uuid,numeric) to authenticated;

-- 3) Registrar un pago de cliente y repartirlo automáticamente a sus pedidos más antiguos.
create or replace function public.register_customer_payment(
  p_customer_id uuid,
  p_amount numeric,
  p_method public.payment_method
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_payment_id uuid;
  v_remaining numeric(12,2) := round(p_amount,2);
  v_balance numeric(12,2);
  v_apply numeric(12,2);
  v_order record;
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  if v_remaining <= 0 then raise exception 'El pago debe ser mayor a cero'; end if;

  insert into public.payments(customer_id, amount, method, created_by)
  values(p_customer_id, v_remaining, p_method, auth.uid())
  returning id into v_payment_id;

  for v_order in
    select o.id,
           greatest(o.total_amount - coalesce((select sum(pa.amount) from public.payment_allocations pa where pa.order_id=o.id),0),0) as balance
    from public.orders o
    where o.customer_id = p_customer_id
      and o.status <> 'cancelled'
    order by o.order_date, o.created_at, o.id
  loop
    exit when v_remaining <= 0;
    v_balance := v_order.balance;
    if v_balance <= 0 then continue; end if;
    v_apply := least(v_remaining, v_balance);
    insert into public.payment_allocations(payment_id, order_id, amount)
    values(v_payment_id, v_order.id, v_apply);
    v_remaining := round(v_remaining - v_apply,2);
  end loop;

  return v_payment_id;
end;
$$;

grant execute on function public.register_customer_payment(uuid,numeric,public.payment_method) to authenticated;

-- 4) Marcar un pedido como enviado y sacar físicamente sus unidades del estado reservado/preparado.
create or replace function public.ship_order(p_order_id uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_number text;
  v_count integer;
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  select order_number into v_number from public.orders where id=p_order_id for update;
  if not found then raise exception 'No existe el pedido'; end if;

  update public.product_units u
  set status='shipped'
  from public.order_items oi
  where oi.order_id=p_order_id
    and oi.product_unit_id=u.id
    and u.status in ('reserved','prepared');

  get diagnostics v_count = row_count;
  update public.orders set fulfillment_status='shipped', status='confirmed' where id=p_order_id;

  insert into public.audit_log(actor_id, entity_type, entity_id, action, details)
  values(auth.uid(), 'order', p_order_id::text, 'shipped', jsonb_build_object('units_changed',v_count));

  return v_number;
end;
$$;

grant execute on function public.ship_order(uuid) to authenticated;

-- 5) Control de asistencia con entrada/salida real.
alter table public.attendance add column if not exists hours_worked numeric(8,2);

create or replace function public.clock_in()
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  if exists(select 1 from public.attendance where worker_id=auth.uid() and clock_out is null) then
    raise exception 'Ya tienes una jornada abierta';
  end if;
  insert into public.attendance(worker_id, clock_in) values(auth.uid(), now()) returning id into v_id;
  return v_id;
end;
$$;

grant execute on function public.clock_in() to authenticated;

create or replace function public.clock_out()
returns numeric
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_hours numeric(8,2);
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  select id into v_id from public.attendance where worker_id=auth.uid() and clock_out is null order by clock_in desc limit 1 for update;
  if not found then raise exception 'No tienes una jornada abierta'; end if;
  update public.attendance
  set clock_out=now(),
      hours_worked=round((extract(epoch from (now()-clock_in))/3600)::numeric,2)
  where id=v_id
  returning hours_worked into v_hours;
  return v_hours;
end;
$$;

grant execute on function public.clock_out() to authenticated;
