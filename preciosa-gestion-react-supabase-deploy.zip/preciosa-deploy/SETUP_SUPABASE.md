# Qué debes hacer tú ahora

Solo hay un paso técnico antes de que el sistema pueda guardar datos reales:

1. Abre tu proyecto **Preciosa Gestión** en Supabase.
2. Entra a **SQL Editor**.
3. Abre `supabase/schema.sql` de este proyecto.
4. Copia TODO su contenido, pégalo en SQL Editor y pulsa **Run**.
5. Crea tu usuario de acceso en **Authentication > Users > Add user** (puede ser tu correo). No necesitas enviarme la contraseña.

Después vuelve aquí y dime únicamente: **“ya ejecuté el SQL”**.

La aplicación ya viene configurada con:
- Project URL: `https://qdbqtnypafgjsgrtparc.supabase.co`
- Publishable Key: la clave que proporcionaste

No se usa la contraseña PostgreSQL para la conexión normal de React.
