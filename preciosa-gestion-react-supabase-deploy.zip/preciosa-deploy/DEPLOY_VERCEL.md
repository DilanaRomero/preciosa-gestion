# Publicar Preciosa Gestión con Vercel

## 1. Subir el proyecto a GitHub
Sube el contenido de esta carpeta a un repositorio nuevo, por ejemplo `preciosa-gestion`.
No subas ningún archivo `.env.local` ni claves secretas.

## 2. Crear el proyecto en Vercel
En Vercel: Add New > Project > Importa el repositorio de GitHub.
Vite será detectado automáticamente. Build command: `npm run build`. Output: `dist`.

## 3. Variables de entorno
En Vercel > Project Settings > Environment Variables agrega:

VITE_SUPABASE_URL=https://qdbqtnypafgjsgrtparc.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=PEGA_AQUI_TU_PUBLISHABLE_KEY

Actívalas para Production, Preview y Development.

## 4. Autenticación de Supabase
Después del primer deploy copia la URL `https://...vercel.app`.
En Supabase > Authentication > URL Configuration:
- Site URL: la URL de producción de Vercel.
- Redirect URL: la URL de producción de Vercel.
- Para previews puedes agregar el patrón recomendado por Supabase para Vercel.

## 5. Probar
Abre la URL de Vercel, escribe el correo de acceso y usa el Magic Link.
